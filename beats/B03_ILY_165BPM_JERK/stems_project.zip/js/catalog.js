// ============================================================
// CATALOG.JS — Chargement des beats, rendu, filtres, modals
// ============================================================

// --- MODAL DÉTAIL ---

window.openDetailModal = function(beatId) {
    const beat = currentBeatsData.find(b => b.id === beatId);
    if (!beat) return;

    document.getElementById('detail-title').textContent = beat.titre;
    document.getElementById('detail-duration').textContent = beat.duree || "--:--";
    document.getElementById('detail-bpm').textContent = beat.bpm || "--";
    document.getElementById('detail-genre').textContent = beat.categorie || "N/A";

    const artworkContainer = document.getElementById('detail-artwork');
    const imgUrl = formatDirectUrl(beat.image_url);
    artworkContainer.innerHTML = imgUrl
        ? `<img src="${imgUrl}" class="w-full h-full object-cover">`
        : `<div class="w-full h-full flex items-center justify-center bg-neutral-900"><i class="fas fa-music text-neutral-600 text-4xl"></i></div>`;

    document.getElementById('beat-detail-modal').classList.remove('hidden');
    document.getElementById('beat-detail-modal').classList.add('flex');
};

window.closeDetailModal = function() {
    document.getElementById('beat-detail-modal').classList.add('hidden');
    document.getElementById('beat-detail-modal').classList.remove('flex');
};

// --- MODAL ACHAT ---

window.openPurchaseModal = function(beatId) {
    const beat = currentBeatsData.find(b => b.id === beatId);
    if (!beat) return;

    document.getElementById('view-licenses').classList.remove('hidden');
    document.getElementById('view-contact').classList.add('hidden');
    document.getElementById('view-confirmation').classList.add('hidden');
    document.getElementById('modal-beat-title').textContent = beat.titre;

    const imgUrl = formatDirectUrl(beat.image_url);
    const modalImg = document.getElementById('modal-beat-image');
    if (modalImg) modalImg.innerHTML = imgUrl
        ? `<img src="${imgUrl}" class="w-full h-full object-cover">`
        : `<div class="w-full h-full flex items-center justify-center bg-neutral-800"><i class="fas fa-music text-neutral-600"></i></div>`;

    const tags = beat.categorie ? beat.categorie.split(',') : ['Beat'];
    const modalTags = document.getElementById('modal-beat-tags');
    if (modalTags) modalTags.innerHTML = tags.map(t =>
        `<span class="bg-neutral-800 text-neutral-400 text-[10px] px-3 py-1 rounded-full uppercase font-bold">${t.trim()}</span>`
    ).join('');

    const customOrderBtn = document.getElementById('btn-custom-order');
    if (customOrderBtn) {
        customOrderBtn.onclick = () => {
            initiateContact(beat.titre, "Custom Instrument", 60000);
        };
    }

    const container = document.getElementById('licenses-container');
    container.innerHTML = '';
    container.className = "licenses-list-wrapper flex md:grid md:grid-cols-3 gap-5 py-4 px-2 w-full overflow-x-auto md:overflow-x-visible snap-x snap-mandatory scrollbar-none";

    const licenses = [
        { name: 'Basic', price: 20000 },
        { name: 'Premium Exclusive', price: 40000 },
        { name: 'Exclusive Pro', price: 50000 }
    ];

    licenses.forEach(lic => {
        const card = document.createElement('div');
        card.className = "license-card bg-neutral-900/60 p-6 rounded-2xl border border-neutral-800/80 hover:border-kosmo-peach transition-all flex flex-col justify-between shadow-lg w-[85vw] md:w-auto shrink-0 snap-center";

        const conditionsHtml = LICENSE_FEATURES[lic.name].map(feat => `
            <li class="flex items-start text-xs text-neutral-400 gap-2.5">
                <i class="fas fa-check text-kosmo-peach text-[10px] mt-1 shrink-0"></i>
                <span>${feat}</span>
            </li>
        `).join('');

        card.innerHTML = `
            <div>
                <div class="flex justify-between items-baseline mb-5">
                    <h4 class="font-extrabold text-white uppercase text-xs tracking-wider">${lic.name}</h4>
                    <span class="text-kosmo-peach font-black text-sm whitespace-nowrap">${lic.price.toLocaleString('fr-FR')} Ar</span>
                </div>
                <ul class="space-y-3 mb-6">
                    ${conditionsHtml}
                </ul>
            </div>
            <div>
                <button onclick="initiateContact('${beat.titre.replace(/'/g, "\\'")}', '${lic.name}', ${lic.price})" class="w-full py-3 bg-kosmo-peach text-kosmo-bg font-black uppercase text-xs tracking-wider rounded-xl mb-3 hover:bg-white transition-colors shadow-sm">Sélectionner</button>
                <div class="flex justify-between items-center px-1">
                    <button onclick="openContractModal('${lic.name}', '${beat.titre.replace(/'/g, "\\'")}')" class="text-[10px] text-neutral-500 uppercase font-bold tracking-widest underline underline-offset-4 hover:text-neutral-300 transition-colors">Voir le terme</button>
                    <a href="licence.html" class="text-[10px] text-kosmo-peach uppercase font-bold tracking-widest underline hover:text-white transition-colors">Détails</a>
                </div>
            </div>
        `;
        container.appendChild(card);
    });

    document.getElementById('purchase-modal').classList.remove('hidden');
    document.getElementById('purchase-modal').classList.add('flex');
};

window.openCustomOrderModal = function() {
    document.getElementById('view-licenses').classList.add('hidden');
    document.getElementById('view-confirmation').classList.add('hidden');
    document.getElementById('modal-beat-title').textContent = "PROJET SUR MESURE";

    const modalImg = document.getElementById('modal-beat-image');
    if (modalImg) modalImg.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-neutral-800 text-kosmo-peach"><i class="fas fa-sliders-h text-2xl"></i></div>`;

    const modalTags = document.getElementById('modal-beat-tags');
    if (modalTags) modalTags.innerHTML = `<span class="bg-kosmo-peach/10 text-kosmo-peach text-[10px] px-3 py-1 rounded-full uppercase font-bold">Création Exclusive</span>`;

    document.getElementById('purchase-modal').classList.remove('hidden');
    document.getElementById('purchase-modal').classList.add('flex');

    initiateContact("Commande Personnalisée", "Custom Instrument", 60000);
};

function closePurchaseModal() {
    document.getElementById('purchase-modal').classList.add('hidden');
    document.getElementById('purchase-modal').classList.remove('flex');
}

// --- MODAL CONTRAT ---

window.openContractModal = function(licenseName, beatTitle) {
    let contractModal = document.getElementById('global-contract-modal');
    if (!contractModal) {
        contractModal = document.createElement('div');
        contractModal.id = 'global-contract-modal';
        contractModal.className = "fixed inset-0 z-[100] hidden items-center justify-center bg-black/80 backdrop-blur-md p-4";
        contractModal.innerHTML = `
            <div class="bg-neutral-950 border border-neutral-800 w-full max-w-2xl h-[85vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl">
                <div class="p-4 border-b border-neutral-900 flex justify-between items-center bg-neutral-900/40">
                    <h3 id="contract-modal-title" class="text-xs font-black uppercase text-kosmo-peach tracking-widest">Contrat de Licence</h3>
                    <button onclick="closeContractModal()" class="text-neutral-400 hover:text-white transition-colors p-1"><i class="fas fa-times text-base"></i></button>
                </div>
                <div class="p-6 overflow-y-auto flex-1 text-xs text-neutral-300 leading-relaxed font-mono whitespace-pre-wrap select-text bg-black/20" id="contract-modal-body"></div>
                <div class="p-4 border-t border-neutral-900 bg-neutral-900/20 text-center">
                    <button onclick="closeContractModal()" class="px-6 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 font-bold uppercase text-[10px] tracking-wider rounded-lg border border-neutral-800 transition-colors">Fermer la lecture</button>
                </div>
            </div>
        `;
        document.body.appendChild(contractModal);
    }

    let contractText = CONTRACT_TEMPLATES[licenseName] || "Aucun contrat disponible.";
    const today = new Date().toLocaleDateString('fr-FR');
    contractText = contractText
        .replace(/\[NOM_BEAT\]/g, beatTitle)
        .replace(/\[DATE_JOUR\]/g, today)
        .replace(/\[NOM_CLIENT\]/g, "l'Artiste / Client");

    document.getElementById('contract-modal-title').textContent = `CONTRAT COMPLET – ${licenseName.toUpperCase()}`;
    document.getElementById('contract-modal-body').textContent = contractText;

    contractModal.classList.remove('hidden');
    contractModal.classList.add('flex');
};

window.closeContractModal = function() {
    const contractModal = document.getElementById('global-contract-modal');
    if (contractModal) {
        contractModal.classList.add('hidden');
        contractModal.classList.remove('flex');
    }
};

// --- CONTACT ET CONFIRMATION ---

window.initiateContact = function(title, type, price) {
    const isCustom = (type === 'Custom Instrument');
    if (!isCustom) {
        document.getElementById('view-licenses').classList.add('hidden');
    }
    document.getElementById('view-contact').classList.remove('hidden');

    const formattedPrice = price.toLocaleString('fr-FR') + " Ar";
    const emailSubject = isCustom
        ? `Commande d'Instrumentale Personnalisée - JOJOH`
        : `Achat de Beat - ${title}`;

    const emailBody = isCustom
        ? `Bonjour JOJOH,%0D%0A%0D%0AJe souhaite commander une production sur mesure personnalisée au tarif de ${formattedPrice}.%0D%0AMerci de me recontacter pour définir la direction artistique (Style, Ambiance, BPM).%0D%0ACordialement.`
        : `Bonjour JOJOH,%0D%0A%0D%0AJe souhaite acheter l'instrumentale "${title}" avec la licence "${type}" au prix de ${formattedPrice}.%0D%0AMerci de me tenir informé des étapes suivantes.%0D%0ACordialement.`;

    const whatsappMsg = isCustom
        ? `Bonjour JOJOH BEATS, je souhaite commander un beat sur mesure personnalisé (Tarif : ${formattedPrice}). Proposons un créneau pour discuter du projet.`
        : `Bonjour JOJOH BEATS, je souhaite acheter le beat "${title}" avec la licence "${type}" à ${formattedPrice} via MVola.`;

    const contactContainer = document.getElementById('view-contact').querySelector('.space-y-3');
    contactContainer.innerHTML = `
        <button id="btn-email" class="w-full bg-neutral-900 border border-neutral-700 hover:border-kosmo-peach p-4 rounded-xl flex items-center justify-between text-white transition-all text-sm font-bold"><span>Email</span><i class="fas fa-envelope text-kosmo-peach"></i></button>
        <button id="btn-whatsapp" class="w-full bg-neutral-900 border border-neutral-700 hover:border-green-500 p-4 rounded-xl flex items-center justify-between text-white transition-all text-sm font-bold"><span>WhatsApp</span><i class="fab fa-whatsapp text-green-500"></i></button>
        <button id="btn-call" class="w-full bg-neutral-900 border border-neutral-700 hover:border-blue-500 p-4 rounded-xl flex items-center justify-between text-white transition-all text-sm font-bold"><span>Appeler</span><i class="fas fa-phone text-blue-500"></i></button>
    `;

    document.getElementById('btn-email').onclick = () => {
        window.location.href = `mailto:nathanjoh721@gmail.com?subject=${emailSubject}&body=${emailBody}`;
        showConfirmation();
    };
    document.getElementById('btn-whatsapp').onclick = () => {
        window.open(`https://wa.me/261341050517?text=${encodeURIComponent(whatsappMsg)}`, '_blank');
        showConfirmation();
    };
    document.getElementById('btn-call').onclick = () => {
        window.location.href = 'tel:+261341050517';
        showConfirmation();
    };
};

function showConfirmation() {
    document.getElementById('view-contact').classList.add('hidden');
    document.getElementById('view-confirmation').classList.remove('hidden');
}

// --- CHARGEMENT ET INITIALISATION ---

async function initApplication() {
    try {
        const response = await fetch(SHEET_BEST_API_URL);
        if (!response.ok) throw new Error("Impossible d'obtenir les données.");
        const data = await response.json();
        currentBeatsData = Array.isArray(data) ? data.filter(beat => beat.statut !== 'exclusive') : [];
        displayedBeats = [...currentBeatsData];

        if (loadingStatus) loadingStatus.classList.add('hidden');
        if (beatsContainer) beatsContainer.classList.remove('hidden');

        setupGenreFilters(currentBeatsData);
        applyFiltersAndRender();
        checkDeepLink();
        setupCustomOrderButton();

        if (searchInput) searchInput.addEventListener('input', applyFiltersAndRender);
        if (genreSelect) genreSelect.addEventListener('change', applyFiltersAndRender);
        if (bpmSelect) bpmSelect.addEventListener('change', applyFiltersAndRender);
        if (sortSelect) sortSelect.addEventListener('change', applyFiltersAndRender);

        // Restaure le player si l'utilisateur revient d'une autre page
        restorePlayerState();
    } catch (error) {
        console.error(error);
        if (loadingStatus) loadingStatus.innerHTML = `<p class="text-neutral-500 text-xs py-10">Une erreur est survenue lors du chargement des morceaux.</p>`;
    }
}

function setupCustomOrderButton() {
    let customSection = document.getElementById('custom-order-section');
    if (!customSection) {
        customSection = document.createElement('div');
        customSection.id = 'custom-order-section';
        customSection.className = "mt-16 mb-8 w-full max-w-4xl mx-auto px-4";
        customSection.innerHTML = `
            <div class="bg-gradient-to-r from-neutral-950 to-neutral-900 border border-neutral-800/80 p-6 sm:p-8 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl text-center sm:text-left">
                <div>
                    <span class="text-kosmo-peach font-black text-[10px] uppercase tracking-widest bg-kosmo-peach/10 px-3 py-1 rounded-full">Exclusivité Totale</span>
                    <h3 class="text-white font-extrabold text-xl sm:text-2xl mt-2.5">Besoin d'un beat unique sur mesure ?</h3>
                    <p class="text-neutral-400 text-xs sm:text-sm mt-1 max-w-xl">Collaborez directement avec JOJOH. Choisissez votre style, structure, instruments et BPM préférés pour façonner votre identity sonore.</p>
                </div>
                <button onclick="openCustomOrderModal()" class="w-full sm:w-auto px-6 py-3 bg-white text-black font-black uppercase text-xs tracking-wider rounded-xl hover:bg-kosmo-peach hover:text-kosmo-bg transition-all shrink-0 shadow-md">
                    Commander (60 000 Ar)
                </button>
            </div>
        `;
        const mainLayout = document.getElementById('beats-container') || document.body;
        mainLayout.after(customSection);
    }
}

function checkDeepLink() {
    const params = new URLSearchParams(window.location.search);
    const beatId = params.get('id');
    if (beatId && currentBeatsData.length > 0) {
        const beatExists = currentBeatsData.find(b => b.id == beatId);
        if (beatExists) {
            renderTableRows();
            setTimeout(() => {
                handlePlayControl(beatId);
                const targetRow = document.querySelector(`tr[onclick*="${beatId}"]`);
                if (targetRow) targetRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 500);
        }
    }
}

function setupGenreFilters(beats) {
    if (!genreSelect) return;
    const genres = ['all', ...new Set(beats.map(b => b.categorie).filter(Boolean))];
    genreSelect.innerHTML = '';
    genres.forEach(g => {
        const option = document.createElement('option');
        option.value = g;
        option.textContent = g === 'all' ? 'Tous les styles' : g.toUpperCase();
        genreSelect.appendChild(option);
    });
}

function applyFiltersAndRender() {
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const activeGenre = genreSelect ? genreSelect.value : 'all';
    const activeBpmRange = bpmSelect ? bpmSelect.value : '';
    const activeSort = sortSelect ? sortSelect.value : '';

    displayedBeats = currentBeatsData.filter(beat => {
        const matchGenre = (activeGenre === 'all' || beat.categorie === activeGenre);
        const bpmVal = parseInt(beat.bpm) || 140;
        let matchBpm = true;

        if (activeBpmRange === 'low') matchBpm = (bpmVal < 100);
        else if (activeBpmRange === 'mid') matchBpm = (bpmVal >= 100 && bpmVal <= 130);
        else if (activeBpmRange === 'high') matchBpm = (bpmVal > 130);

        const matchSearch = !query
            || (beat.titre || '').toLowerCase().includes(query)
            || (beat.categorie || '').toLowerCase().includes(query);

        return matchGenre && matchBpm && matchSearch;
    });

    if (activeSort === 'price-asc') displayedBeats.sort((a, b) => getCleanPrice(a) - getCleanPrice(b));
    else if (activeSort === 'price-desc') displayedBeats.sort((a, b) => getCleanPrice(b) - getCleanPrice(a));

    renderTableRows();
}

function renderTableRows() {
    if (!beatsTableBody) return;
    beatsTableBody.innerHTML = '';

    if (displayedBeats.length === 0) {
        beatsTableBody.innerHTML = `<tr><td colspan="5" class="text-center py-16 text-neutral-600 text-xs">Aucune instrumentale ne correspond à vos critères.</td></tr>`;
        return;
    }

    displayedBeats.forEach((beat, index) => {
        const isCurrent = (playingBeatId === beat.id);
        const isPlaying = isCurrent && !audioElement.paused;
        const priceNumeric = getCleanPrice(beat);
        const directImageUrl = formatDirectUrl(beat.image_url);

        const row = document.createElement('tr');
        row.className = `beat-row border-b border-white/5 group align-middle cursor-pointer ${isCurrent ? 'bg-white/[0.05]' : ''}`;
        row.setAttribute('onclick', `handleRowClick(event, '${beat.id}')`);

        const bpmValue = beat.bpm || "--";
        const durationValue = beat.duree || "--:--";

        const tagsArray = beat.categorie ? beat.categorie.split(',') : ['Instrumental'];
        let tagsHTML = '';
        tagsArray.slice(0, 2).forEach(tag => {
            tagsHTML += `<span class="bg-black/20 text-neutral-300 text-[9px] font-semibold px-2 py-0.5 rounded-md uppercase tracking-wider mr-1">${tag.trim()}</span>`;
        });

        const coverHTML = directImageUrl
            ? `<img src="${directImageUrl}" class="custom-mobile-cover w-14 h-14 object-cover rounded-xl mr-3 shrink-0" alt="">`
            : `<div class="custom-mobile-cover w-14 h-14 bg-neutral-900 rounded-xl flex items-center justify-center text-neutral-600 mr-3 shrink-0"><i class="fas fa-compact-disc"></i></div>`;

        row.innerHTML = `
            <td class="py-3 sm:py-4 flex items-center pr-2">
                <div class="relative flex items-center overflow-hidden">
                    <div class="w-5 sm:w-6 text-neutral-400 text-[10px] sm:text-[11px] font-bold shrink-0 group-hover:opacity-0 transition-opacity">
                        ${isCurrent && isPlaying ? '<i class="fas fa-volume-up text-kosmo-peach animate-pulse"></i>' : index + 1}
                    </div>
                </div>
                ${coverHTML}
                <div class="overflow-hidden">
                    <h3 class="font-bold text-[12px] sm:text-lg text-white ${isCurrent ? 'text-kosmo-peach' : ''} cursor-pointer hover:underline"
                        onclick="event.stopPropagation(); openDetailModal('${beat.id}')">
                        ${beat.titre}
                    </h3>
                </div>
            </td>
            <td class="py-3 sm:py-4 text-center text-[10px] sm:text-xs font-semibold text-neutral-300">${durationValue}</td>
            <td class="py-3 sm:py-4 text-center text-[10px] sm:text-xs font-semibold text-neutral-300 hidden md:table-cell">${bpmValue}</td>
            <td class="py-3 sm:py-4 text-[10px] sm:text-xs font-semibold whitespace-nowrap">${tagsHTML}</td>
            <td class="py-3 sm:py-4 text-right">
                <div class="flex items-center justify-end gap-2" onclick="event.stopPropagation()">
                    <button onclick="shareBeat(event, '${beat.id}')" class="p-2 text-neutral-400 hover:text-kosmo-peach transition-colors group" title="Partager ce beat">
                        <i class="fas fa-share-alt text-xs"></i>
                    </button>
                    <button onclick="openPurchaseModal('${beat.id}')" class="bg-kosmo-peach hover:bg-[#e2b991] text-kosmo-bg text-[10px] sm:text-xs font-extrabold px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg uppercase tracking-widest transition-all whitespace-nowrap">
                        <i class="fas fa-shopping-cart sm:mr-1"></i> <span class="hidden sm:inline">${priceNumeric.toLocaleString('fr-FR')} Ar</span>
                    </button>
                </div>
            </td>
        `;
        beatsTableBody.appendChild(row);
    });
}

window.handleRowClick = function(event, beatId) {
    handlePlayControl(beatId);
};
