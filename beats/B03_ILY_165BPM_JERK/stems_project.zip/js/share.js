// ============================================================
// SHARE.JS — Modal de partage, story card style Spotify
// ============================================================

let currentShareBeatId = null;

// --- OUVERTURE / FERMETURE DU MODAL ---

window.shareBeat = function(event, beatId) {
    event.stopPropagation();
    openShareModal(beatId);
};

window.openShareModal = function(beatId) {
    const beat = currentBeatsData.find(b => b.id === beatId);
    if (!beat) return;

    currentShareBeatId = beatId;

    const imgUrl = formatDirectUrl(beat.image_url);

    // Remplir la story card prévisualisation
    const storyBg = document.getElementById('share-story-bg');
    const storyArt = document.getElementById('share-story-art');
    const storyTitle = document.getElementById('share-story-title');
    const storyGenre = document.getElementById('share-story-genre');

    if (storyBg) {
        storyBg.style.backgroundImage = imgUrl ? `url('${imgUrl}')` : 'none';
    }
    if (storyArt) {
        storyArt.innerHTML = imgUrl
            ? `<img src="${imgUrl}" class="w-full h-full object-cover">`
            : `<i class="fas fa-music text-neutral-600 text-2xl"></i>`;
    }
    if (storyTitle) storyTitle.textContent = beat.titre.toUpperCase();
    if (storyGenre) storyGenre.textContent = beat.categorie ? beat.categorie.toUpperCase() : 'BEAT';

    // Réinitialiser le bouton copier
    const copyLabel = document.getElementById('share-copy-label');
    const copyBtn = document.getElementById('share-copy-btn');
    if (copyLabel) copyLabel.textContent = 'Copier le lien du beat';
    if (copyBtn) copyBtn.classList.remove('border-green-500');

    const shareModal = document.getElementById('share-modal');
    if (shareModal) {
        shareModal.classList.remove('hidden');
        shareModal.classList.add('flex');
    }
};

window.closeShareModal = function() {
    const shareModal = document.getElementById('share-modal');
    if (shareModal) {
        shareModal.classList.add('hidden');
        shareModal.classList.remove('flex');
    }
    currentShareBeatId = null;
};

// --- CONSTRUCTION DE L'URL DE PARTAGE ---

function buildShareUrl(beatId) {
    return `${SITE_BASE_URL}/index.html?id=${beatId}`;
}

// --- PARTAGE FACEBOOK ---

window.shareToFacebook = function() {
    if (!currentShareBeatId) return;
    const shareUrl = encodeURIComponent(buildShareUrl(currentShareBeatId));
    window.open(
        `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`,
        '_blank',
        'width=600,height=400'
    );
};

// --- TÉLÉCHARGEMENT DE LA STORY INSTAGRAM (Canvas PNG) ---

window.downloadStoryCard = function() {
    if (!currentShareBeatId) return;
    const beat = currentBeatsData.find(b => b.id === currentShareBeatId);
    if (!beat) return;

    const imgUrl = formatDirectUrl(beat.image_url);

    generateStoryCardCanvas(beat, imgUrl, function(dataUrl) {
        const link = document.createElement('a');
        link.download = `jojoh-beats-${beat.titre.replace(/\s+/g, '-').toLowerCase()}-story.png`;
        link.href = dataUrl;
        link.click();
    });
};

// --- COPIER LE LIEN ---

window.copyShareLink = function() {
    if (!currentShareBeatId) return;
    const shareUrl = buildShareUrl(currentShareBeatId);

    const applySuccess = () => {
        const copyLabel = document.getElementById('share-copy-label');
        const copyBtn = document.getElementById('share-copy-btn');
        if (copyLabel) copyLabel.textContent = 'Lien copié !';
        if (copyBtn) copyBtn.classList.add('border-green-500');
        setTimeout(() => {
            if (copyLabel) copyLabel.textContent = 'Copier le lien du beat';
            if (copyBtn) copyBtn.classList.remove('border-green-500');
        }, 2500);
    };

    navigator.clipboard.writeText(shareUrl).then(applySuccess).catch(() => {
        // Fallback pour les navigateurs sans clipboard API
        const textarea = document.createElement('textarea');
        textarea.value = shareUrl;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        applySuccess();
    });
};

// --- GÉNÉRATION DE LA STORY CARD 1080x1920 VIA CANVAS ---

function generateStoryCardCanvas(beat, imgUrl, callback) {
    const storyCanvas = document.createElement('canvas');
    storyCanvas.width = 1080;
    storyCanvas.height = 1920;
    const ctx = storyCanvas.getContext('2d');

    function drawCard(bgImg) {
        // Fond sombre de base
        ctx.fillStyle = '#0a0a0c';
        ctx.fillRect(0, 0, 1080, 1920);

        // Image de fond flouée si disponible
        if (bgImg) {
            ctx.save();
            ctx.filter = 'blur(60px) brightness(0.4) saturate(1.5)';
            ctx.drawImage(bgImg, -150, -150, 1380, 2220);
            ctx.restore();
        }

        // Dégradé sombre par-dessus l'image de fond
        const grad = ctx.createLinearGradient(0, 0, 0, 1920);
        grad.addColorStop(0, 'rgba(10,10,12,0.75)');
        grad.addColorStop(0.45, 'rgba(10,10,12,0.25)');
        grad.addColorStop(1, 'rgba(10,10,12,0.92)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1080, 1920);

        // Label "En écoute sur"
        ctx.fillStyle = 'rgba(249,204,157,0.85)';
        ctx.font = 'bold 38px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('En écoute sur', 540, 310);

        // Nom de la marque
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 90px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('JOJOH BEATS', 540, 415);

        // Pochette au centre
        const artSize = 820;
        const artX = (1080 - artSize) / 2;
        const artY = 490;

        if (bgImg) {
            ctx.save();
            ctx.beginPath();
            if (ctx.roundRect) {
                ctx.roundRect(artX, artY, artSize, artSize, 48);
            } else {
                ctx.rect(artX, artY, artSize, artSize);
            }
            ctx.clip();
            ctx.drawImage(bgImg, artX, artY, artSize, artSize);
            ctx.restore();

            // Bordure légère sur la pochette
            ctx.save();
            ctx.beginPath();
            if (ctx.roundRect) {
                ctx.roundRect(artX, artY, artSize, artSize, 48);
            } else {
                ctx.rect(artX, artY, artSize, artSize);
            }
            ctx.strokeStyle = 'rgba(255,255,255,0.12)';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.restore();
        } else {
            // Placeholder si pas d'image disponible
            ctx.fillStyle = '#1a1a1f';
            ctx.beginPath();
            if (ctx.roundRect) {
                ctx.roundRect(artX, artY, artSize, artSize, 48);
            } else {
                ctx.rect(artX, artY, artSize, artSize);
            }
            ctx.fill();
        }

        // Titre du beat (adapte la taille si trop long)
        const titleY = artY + artSize + 110;
        const titleText = beat.titre.toUpperCase();
        ctx.fillStyle = '#ffffff';
        let titleFontSize = 72;
        ctx.font = `bold ${titleFontSize}px sans-serif`;
        while (ctx.measureText(titleText).width > 920 && titleFontSize > 40) {
            titleFontSize -= 4;
            ctx.font = `bold ${titleFontSize}px sans-serif`;
        }
        ctx.textAlign = 'center';
        ctx.fillText(titleText, 540, titleY);

        // Genre du beat
        if (beat.categorie) {
            ctx.fillStyle = '#f9cc9d';
            ctx.font = 'bold 44px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(beat.categorie.toUpperCase(), 540, titleY + 70);
        }

        // Séparateur décoratif
        ctx.strokeStyle = 'rgba(249,204,157,0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(390, 1770);
        ctx.lineTo(690, 1770);
        ctx.stroke();

        // URL du site en bas
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.font = '38px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('jojoh.kesug.com', 540, 1830);

        callback(storyCanvas.toDataURL('image/png'));
    }

    if (imgUrl) {
        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = () => drawCard(img);
        img.onerror = () => drawCard(null);
        img.src = imgUrl;
    } else {
        drawCard(null);
    }
}
