// ============================================================
// PLAYER-MINI.JS — Mini-player persistant pour pages secondaires
// ============================================================

(function () {
    'use strict';

    const savedBeatId  = localStorage.getItem('jojoh_beatId');
    const audioUrl     = localStorage.getItem('jojoh_audioUrl') || '';
    const imageUrl     = localStorage.getItem('jojoh_imageUrl') || '';
    const beatTitle    = localStorage.getItem('jojoh_beatTitle') || 'Beat en cours';
    const beatGenre    = localStorage.getItem('jojoh_beatGenre') || '';
    const savedTime    = parseFloat(localStorage.getItem('jojoh_currentTime') || '0');
    const wasPlaying   = localStorage.getItem('jojoh_isPlaying') === 'true';

    if (!savedBeatId || !audioUrl) return;

    const audio = document.createElement('audio');
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';
    audio.src = audioUrl;
    document.body.appendChild(audio);

    let isPlaying = false;

    function formatTime(sec) {
        if (isNaN(sec) || sec < 0) return '0:00';
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60);
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    function saveState() {
        try {
            localStorage.setItem('jojoh_currentTime', audio.currentTime.toString());
            localStorage.setItem('jojoh_isPlaying', isPlaying.toString());
        } catch (e) {}
    }

    function clearState() {
        try {
            ['jojoh_beatId','jojoh_currentTime','jojoh_isPlaying',
             'jojoh_beatTitle','jojoh_beatGenre','jojoh_audioUrl','jojoh_imageUrl']
            .forEach(k => localStorage.removeItem(k));
        } catch (e) {}
    }

    const coverHTML = imageUrl
        ? `<img src="${imageUrl}" style="width:100%;height:100%;object-fit:cover;">`
        : `<i class="fas fa-music" style="color:#7d7d7f;font-size:10px;"></i>`;

    const playerHTML = `
    <div id="mini-player-bar"
         style="position:fixed;bottom:0;left:0;right:0;z-index:9999;
                background:rgba(10,10,12,0.97);
                backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
                border-top:1px solid rgba(255,255,255,0.08);
                padding:10px 16px;
                font-family:'Sora',sans-serif;">
        <div style="max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:12px;">

            <div style="display:flex;align-items:center;gap:12px;flex:0 0 auto;max-width:38%;">
                <a href="index.html?id=${savedBeatId}"
                   style="display:flex;width:52px;height:52px;border-radius:10px;overflow:hidden;
                          background:#1a1a1f;border:1px solid rgba(255,255,255,0.06);
                          align-items:center;justify-content:center;flex-shrink:0;text-decoration:none;">
                    ${coverHTML}
                </a>
                <div style="overflow:hidden;">
                    <a href="index.html?id=${savedBeatId}"
                       style="display:block;font-weight:700;color:#ffffff;font-size:12px;
                              white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
                              max-width:150px;text-decoration:none;line-height:1.3;">
                        ${beatTitle}
                    </a>
                    <span style="font-size:10px;color:#f9cc9d;text-transform:uppercase;
                                 letter-spacing:0.08em;font-weight:600;">
                        ${beatGenre || 'Beat'}
                    </span>
                </div>
            </div>

            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;min-width:0;">
                <button id="mini-play-btn"
                        style="width:38px;height:38px;border-radius:50%;background:#ffffff;
                               color:#0a0a0c;border:none;cursor:pointer;
                               display:flex;align-items:center;justify-content:center;
                               font-size:11px;flex-shrink:0;">
                    <i class="fas fa-play" style="padding-left:2px;"></i>
                </button>
                <div style="width:100%;display:flex;align-items:center;gap:8px;">
                    <span id="mini-current-time"
                          style="font-size:9px;color:#7d7d7f;font-weight:600;white-space:nowrap;min-width:28px;">
                        0:00
                    </span>
                    <div id="mini-progress-container"
                         style="flex:1;height:3px;background:rgba(255,255,255,0.1);
                                border-radius:99px;cursor:pointer;position:relative;">
                        <div id="mini-progress-bar"
                             style="height:100%;width:0%;background:#f9cc9d;
                                    border-radius:99px;transition:width 0.1s linear;position:relative;">
                            <div style="position:absolute;right:-5px;top:50%;transform:translateY(-50%);
                                        width:10px;height:10px;background:#f9cc9d;border-radius:50%;
                                        box-shadow:0 0 4px rgba(0,0,0,0.5);"></div>
                        </div>
                    </div>
                    <span id="mini-total-duration"
                          style="font-size:9px;color:#7d7d7f;font-weight:600;white-space:nowrap;min-width:28px;text-align:right;">
                        0:00
                    </span>
                </div>
            </div>

            <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                <a href="index.html"
                   id="mini-back-btn"
                   style="display:none;background:#f9cc9d;color:#0a0a0c;font-weight:800;
                          font-size:9px;text-transform:uppercase;letter-spacing:0.1em;
                          padding:8px 14px;border-radius:99px;text-decoration:none;white-space:nowrap;">
                    Catalogue
                </a>
                <button id="mini-close-btn"
                        style="background:none;border:none;color:rgba(255,255,255,0.4);
                               cursor:pointer;font-size:14px;padding:4px;line-height:1;">
                    <i class="fas fa-times"></i>
                </button>
            </div>

        </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', playerHTML);
    document.body.style.paddingBottom = '80px';

    const backBtn = document.getElementById('mini-back-btn');
    if (backBtn && window.innerWidth >= 640) backBtn.style.display = 'inline-flex';

    const playBtn           = document.getElementById('mini-play-btn');
    const progressBar       = document.getElementById('mini-progress-bar');
    const progressContainer = document.getElementById('mini-progress-container');
    const currentTimeEl     = document.getElementById('mini-current-time');
    const totalDurationEl   = document.getElementById('mini-total-duration');
    const closeBtn          = document.getElementById('mini-close-btn');

    function setPlayIcon() {
        playBtn.innerHTML = isPlaying
            ? '<i class="fas fa-pause" style="font-size:11px;"></i>'
            : '<i class="fas fa-play" style="font-size:11px;padding-left:2px;"></i>';
    }

    playBtn.addEventListener('click', () => {
        if (isPlaying) {
            audio.pause();
            isPlaying = false;
        } else {
            audio.play().catch(() => {});
            isPlaying = true;
        }
        setPlayIcon();
        saveState();
    });

    audio.addEventListener('timeupdate', () => {
        if (audio.duration && !isNaN(audio.duration)) {
            const percent = (audio.currentTime / audio.duration) * 100;
            progressBar.style.width = `${percent}%`;
            currentTimeEl.textContent = formatTime(audio.currentTime);
        }
    });

    audio.addEventListener('loadedmetadata', () => {
        if (!isNaN(audio.duration)) {
            totalDurationEl.textContent = formatTime(audio.duration);
            audio.currentTime = savedTime;
            if (wasPlaying) {
                audio.play().then(() => {
                    isPlaying = true;
                    setPlayIcon();
                }).catch(() => {});
            }
        }
    });

    audio.addEventListener('ended', () => {
        isPlaying = false;
        setPlayIcon();
        saveState();
    });

    progressContainer.addEventListener('click', (e) => {
        const rect = progressContainer.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const width = progressContainer.clientWidth;
        if (audio.duration && !isNaN(audio.duration)) {
            audio.currentTime = (clickX / width) * audio.duration;
        }
    });

    closeBtn.addEventListener('click', () => {
        audio.pause();
        clearState();
        const bar = document.getElementById('mini-player-bar');
        if (bar) bar.remove();
        document.body.style.paddingBottom = '';
    });

    window.addEventListener('beforeunload', saveState);

    document.addEventListener('click', function (e) {
        const link = e.target.closest('a[href]');
        if (link) {
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !href.startsWith('http')
                && !href.startsWith('mailto') && !href.startsWith('tel')) {
                saveState();
            }
        }
    });

    audio.load();

})();