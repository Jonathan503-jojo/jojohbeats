// ============================================================
// PLAYER.JS — Lecteur audio, waveform, persistance, contrôles
// ============================================================

// --- WAVEFORM (WEB AUDIO API) ---
const canvas = document.getElementById("waveform-canvas");
const canvasCtx = canvas ? canvas.getContext("2d") : null;
let audioCtx = null;
let audioSource = null;
let analyser = null;
let isAudioInitialized = false;
let animationFrameId = null;

function resizeCanvas() {
    if (canvas) {
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
    }
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

function initAudioAnalyzer() {
    if (isAudioInitialized || !canvasCtx) return;
    try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        audioSource = audioCtx.createMediaElementSource(audioElement);
        audioSource.connect(analyser);
        analyser.connect(audioCtx.destination);
        isAudioInitialized = true;
        drawWaveform();
    } catch (e) {
        console.error("L'analyseur audio n'a pas pu démarrer :", e);
    }
}

function drawWaveform() {
    animationFrameId = requestAnimationFrame(drawWaveform);
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyser.getByteFrequencyData(dataArray);
    canvasCtx.clearRect(0, 0, canvas.width, canvas.height);

    const activeLength = Math.floor(bufferLength * 0.70);
    const barWidth = (canvas.width / 2) / activeLength;
    let barHeight;

    for (let i = 0; i < activeLength; i++) {
        barHeight = (dataArray[i] / 255) * canvas.height * 1.2;
        const opacity = 0.4 + ((dataArray[i] / 255) * 0.6);
        canvasCtx.fillStyle = `rgba(249, 204, 157, ${opacity})`;

        const y = (canvas.height - barHeight) / 2;
        const xRight = (canvas.width / 2) + (i * barWidth);
        const xLeft = (canvas.width / 2) - (i * barWidth) - barWidth;

        canvasCtx.beginPath();
        if (canvasCtx.roundRect) {
            canvasCtx.roundRect(xRight, y, barWidth - 1.5, barHeight, 4);
        } else {
            canvasCtx.rect(xRight, y, barWidth - 1.5, barHeight);
        }
        canvasCtx.fill();

        canvasCtx.beginPath();
        if (canvasCtx.roundRect) {
            canvasCtx.roundRect(xLeft, y, barWidth - 1.5, barHeight, 4);
        } else {
            canvasCtx.rect(xLeft, y, barWidth - 1.5, barHeight);
        }
        canvasCtx.fill();
    }
}

// --- PERSISTANCE DU PLAYER ENTRE LES PAGES ---

function savePlayerState() {
    if (playingBeatId) {
        const beat = currentBeatsData.find(b => b.id === playingBeatId);
        try {
            localStorage.setItem('jojoh_beatId', playingBeatId);
            localStorage.setItem('jojoh_currentTime', audioElement.currentTime.toString());
            localStorage.setItem('jojoh_isPlaying', (!audioElement.paused).toString());
            if (beat) {
                localStorage.setItem('jojoh_beatTitle', beat.titre || '');
                localStorage.setItem('jojoh_beatGenre', beat.categorie || '');
                localStorage.setItem('jojoh_audioUrl', formatDirectUrl(beat.audio_url) || '');
                localStorage.setItem('jojoh_imageUrl', formatDirectUrl(beat.image_url) || '');
            }
        } catch(e) {}
    }
}

function clearPlayerState() {
    try {
        localStorage.removeItem('jojoh_beatId');
        localStorage.removeItem('jojoh_currentTime');
        localStorage.removeItem('jojoh_isPlaying');
        localStorage.removeItem('jojoh_beatTitle');
        localStorage.removeItem('jojoh_beatGenre');
        localStorage.removeItem('jojoh_audioUrl');
        localStorage.removeItem('jojoh_imageUrl');
    } catch(e) {}
}

function restorePlayerState() {
    try {
        const savedBeatId = localStorage.getItem('jojoh_beatId');
        const savedTime = parseFloat(localStorage.getItem('jojoh_currentTime') || '0');
        const wasPlaying = localStorage.getItem('jojoh_isPlaying') === 'true';

        if (!savedBeatId || currentBeatsData.length === 0) return;

        const beat = currentBeatsData.find(b => b.id === savedBeatId);
        if (!beat) return;

        const directAudioUrl = formatDirectUrl(beat.audio_url);
        const directImageUrl = formatDirectUrl(beat.image_url);

        playingBeatId = savedBeatId;
        audioElement.src = directAudioUrl;

        audioElement.addEventListener('loadedmetadata', function onMeta() {
            audioElement.removeEventListener('loadedmetadata', onMeta);
            audioElement.currentTime = savedTime;
            if (wasPlaying) {
                audioElement.play().catch(() => {});
                initAudioAnalyzer();
            }
        }, { once: true });

        if (directImageUrl) {
            updateThemeFromImage(directImageUrl);
            const overlayArtwork = document.getElementById('overlay-artwork');
            if (overlayArtwork) overlayArtwork.innerHTML = `<img src="${directImageUrl}" class="w-full h-full object-cover rounded-2xl shadow-2xl">`;
        }

        if (globalPlayer) globalPlayer.classList.remove('translate-y-full');
        if (playerTitle) playerTitle.textContent = beat.titre;
        if (playerGenre) playerGenre.textContent = beat.categorie || 'Beat';
        if (playerImage) playerImage.innerHTML = directImageUrl
            ? `<img src="${directImageUrl}" class="w-full h-full object-cover">`
            : `<i class="fas fa-music text-xs text-neutral-500"></i>`;

        const overlayTitle = document.getElementById('overlay-title');
        const overlayGenre = document.getElementById('overlay-genre');
        if (overlayTitle) overlayTitle.textContent = beat.titre;
        if (overlayGenre) overlayGenre.textContent = beat.categorie || 'Beat';

        updatePlayerUI(wasPlaying);
    } catch(e) {}
}

window.addEventListener('beforeunload', savePlayerState);

document.addEventListener('click', function(e) {
    const link = e.target.closest('a[href]');
    if (link) {
        const href = link.getAttribute('href');
        if (href && !href.startsWith('#') && !href.startsWith('http') && !href.startsWith('mailto') && !href.startsWith('tel')) {
            savePlayerState();
        }
    }
});

// --- CONTRÔLE DU VOLUME ---

if (volumeToggleBtn && volumeSliderContainer && volumeSlider) {
    volumeToggleBtn.addEventListener('click', () => {
        volumeSliderContainer.classList.toggle('hidden');
        if (!volumeSliderContainer.classList.contains('hidden') && window.innerWidth <= 640) {
            volumeSlider.classList.add('vertical-slider');
            volumeSliderContainer.style.position = 'absolute';
            volumeSliderContainer.style.bottom = '70px';
            volumeSliderContainer.style.right = '20px';
            volumeSliderContainer.style.zIndex = '100';
        } else {
            volumeSlider.classList.remove('vertical-slider');
            volumeSliderContainer.style.position = '';
            volumeSliderContainer.style.bottom = '';
            volumeSliderContainer.style.right = '';
        }
    });
}

if (volumeSlider) {
    volumeSlider.addEventListener('input', (e) => {
        audioElement.volume = e.target.value;
    });
}

// --- LOGIQUE DE LECTURE ---

function handlePlayControl(beatId) {
    const beat = currentBeatsData.find(b => b.id === beatId);
    if (!beat) return;

    const directAudioUrl = formatDirectUrl(beat.audio_url);
    const directImageUrl = formatDirectUrl(beat.image_url);

    if (playingBeatId === beatId) {
        if (audioElement.paused) {
            audioElement.play();
            if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            updatePlayerUI(true);
        } else {
            audioElement.pause();
            updatePlayerUI(false);
        }
    } else {
        playingBeatId = beatId;
        audioElement.src = directAudioUrl;
        audioElement.play();

        initAudioAnalyzer();
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();

        if (directImageUrl) {
            updateThemeFromImage(directImageUrl);
            const overlayArtwork = document.getElementById('overlay-artwork');
            if (overlayArtwork) overlayArtwork.innerHTML = `<img src="${directImageUrl}" class="w-full h-full object-cover rounded-2xl shadow-2xl">`;
        }

        if (globalPlayer) globalPlayer.classList.remove('translate-y-full');
        if (playerTitle) playerTitle.textContent = beat.titre;

        const overlayTitle = document.getElementById('overlay-title');
        const overlayGenre = document.getElementById('overlay-genre');
        if (overlayTitle) overlayTitle.textContent = beat.titre;
        if (overlayGenre) overlayGenre.textContent = beat.categorie || 'Beat';

        if (playerGenre) playerGenre.textContent = beat.categorie || 'Beat';
        if (playerImage) playerImage.innerHTML = directImageUrl
            ? `<img src="${directImageUrl}" class="w-full h-full object-cover">`
            : `<i class="fas fa-music text-xs text-neutral-500"></i>`;

        updatePlayerUI(true);
    }
}

function updatePlayerUI(isPlaying) {
    const iconHTML = isPlaying
        ? `<i class="fas fa-pause text-xs"></i>`
        : `<i class="fas fa-play text-xs pl-0.5"></i>`;
    if (playerPlayBtn) playerPlayBtn.innerHTML = iconHTML;

    const overlayPlayBtn = document.getElementById('overlay-play-btn');
    if (overlayPlayBtn) overlayPlayBtn.innerHTML = isPlaying
        ? `<i class="fas fa-pause"></i>`
        : `<i class="fas fa-play"></i>`;

    renderTableRows();
}

function playNext() {
    if (displayedBeats.length === 0) return;
    let currentIndex = displayedBeats.findIndex(b => b.id === playingBeatId);
    let nextIndex;
    if (isShuffle) {
        nextIndex = Math.floor(Math.random() * displayedBeats.length);
    } else {
        nextIndex = (currentIndex + 1) % displayedBeats.length;
    }
    handlePlayControl(displayedBeats[nextIndex].id);
}

function playPrev() {
    if (displayedBeats.length === 0) return;
    let cur = displayedBeats.findIndex(b => b.id === playingBeatId);
    let prevIndex = (cur - 1 + displayedBeats.length) % displayedBeats.length;
    handlePlayControl(displayedBeats[prevIndex].id);
}

if (playerPlayBtn) playerPlayBtn.addEventListener('click', () => playingBeatId && handlePlayControl(playingBeatId));
if (playerNextBtn) playerNextBtn.addEventListener('click', playNext);
if (playerPrevBtn) playerPrevBtn.addEventListener('click', playPrev);

if (playerShuffleBtn) {
    playerShuffleBtn.style.transition = "all 0.3s ease";
    playerShuffleBtn.style.opacity = isShuffle ? "1" : "0.4";
    playerShuffleBtn.addEventListener('click', () => {
        isShuffle = !isShuffle;
        playerShuffleBtn.classList.toggle('text-kosmo-peach', isShuffle);
        playerShuffleBtn.style.opacity = isShuffle ? "1" : "0.4";
    });
}

if (playerLoopBtn) {
    playerLoopBtn.style.transition = "all 0.3s ease";
    playerLoopBtn.style.opacity = isLoop ? "1" : "0.4";
    playerLoopBtn.addEventListener('click', () => {
        isLoop = !isLoop;
        playerLoopBtn.classList.toggle('text-kosmo-peach', isLoop);
        playerLoopBtn.style.opacity = isLoop ? "1" : "0.4";
    });
}

if (playerShareBtn) {
    playerShareBtn.addEventListener('click', () => {
        if (!playingBeatId) return;
        openShareModal(playingBeatId);
    });
}

if (playerCloseBtn) playerCloseBtn.addEventListener('click', () => {
    audioElement.pause();
    updatePlayerUI(false);
    clearPlayerState();
    if (globalPlayer) {
        globalPlayer.classList.add('translate-y-full');
        globalPlayer.classList.remove('player-fullscreen');
    }
});

// --- ÉVÉNEMENTS AUDIO ---

audioElement.addEventListener('timeupdate', () => {
    if (audioElement.duration && !isNaN(audioElement.duration)) {
        const percent = (audioElement.currentTime / audioElement.duration) * 100;

        if (progressBar) progressBar.style.width = `${percent}%`;
        if (currentTimeEl) currentTimeEl.textContent = formatTime(audioElement.currentTime);

        const overlayProgressBar = document.getElementById('overlay-progress-bar');
        if (overlayProgressBar) overlayProgressBar.style.width = `${percent}%`;

        const overlayCurrentTime = document.getElementById('overlay-current-time');
        if (overlayCurrentTime) overlayCurrentTime.textContent = formatTime(audioElement.currentTime);
    }
});

audioElement.addEventListener('loadedmetadata', () => {
    if (!isNaN(audioElement.duration)) {
        const formattedDuration = formatTime(audioElement.duration);
        if (totalDurationEl) totalDurationEl.textContent = formattedDuration;
        const overlayTotalDuration = document.getElementById('overlay-total-duration');
        if (overlayTotalDuration) overlayTotalDuration.textContent = formattedDuration;
    }
});

audioElement.addEventListener('ended', () => {
    if (isLoop) {
        audioElement.currentTime = 0;
        audioElement.play();
    } else {
        playNext();
    }
});

if (progressContainer) {
    progressContainer.addEventListener('click', (e) => {
        const width = progressContainer.clientWidth;
        const clickX = e.offsetX;
        if (audioElement.duration && !isNaN(audioElement.duration)) {
            audioElement.currentTime = (clickX / width) * audioElement.duration;
        }
    });
}

const overlayProgressContainer = document.getElementById('overlay-progress-container');
if (overlayProgressContainer) {
    overlayProgressContainer.addEventListener('click', (e) => {
        const width = overlayProgressContainer.clientWidth;
        const clickX = e.offsetX;
        if (audioElement.duration && !isNaN(audioElement.duration)) {
            audioElement.currentTime = (clickX / width) * audioElement.duration;
        }
    });
}