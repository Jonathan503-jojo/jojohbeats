// licences-data.js

export const CONTRACT_TEMPLATES = {

    'Basic': `
CONTRAT DE LICENCE NON-EXCLUSIVE – BASIC

DE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)
À : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)

DATE D’ENTENTE : [DATE_JOUR]


Le présent contrat concerne la licence de l'instrumentale intitulée "[NOM_BEAT]" créée et produite par Jonathan, connu professionnellement sous le nom de JOJOH BEATS.


1. FRAIS DE LICENCE

Le montant de cette licence est fixé à :

20 000 Ariary

La licence devient valide uniquement après réception complète du paiement.


2. TYPE DE LICENCE

Cette licence est une licence NON EXCLUSIVE.

Le Producteur conserve tous ses droits sur l'instrumentale et peut continuer à proposer cette même œuvre à d'autres artistes.


3. FORMAT LIVRÉ

Le Licencié reçoit l'instrumentale dans les formats disponibles :

- MP3 haute qualité
- WAV haute qualité


4. DROITS D'UTILISATION

Le Licencié est autorisé à :

- Utiliser l'instrumentale pour créer une chanson originale.
- Publier son morceau sur les plateformes digitales.
- Utiliser son morceau sur les réseaux sociaux.
- Exploiter son projet selon les limites définies par cette licence.


5. RESTRICTIONS

Le Licencié ne peut pas :

- Revendre l'instrumentale originale.
- Donner l'accès au fichier instrumental à une autre personne.
- Déclarer être le compositeur exclusif de la musique.


6. CRÉDIT PRODUCTEUR

Le crédit obligatoire doit apparaître sous la forme :

"Prod. by JOJOH BEATS"

ou

"Produit par JOJOH"


7. PROPRIÉTÉ

La composition instrumentale originale reste la propriété de JOJOH BEATS.
Cette licence accorde uniquement un droit d'utilisation.


`,
    'Premium Exclusive': `
CONTRAT DE LICENCE EXCLUSIVE – PREMIUM EXCLUSIVE


DE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)

À : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)


DATE D’ENTENTE : [DATE_JOUR]


Le présent contrat concerne l'acquisition d'une licence exclusive pour l'instrumentale intitulée "[NOM_BEAT]" créée par JOJOH BEATS.


1. FRAIS DE LICENCE

Le prix de cette licence exclusive est fixé à :

40 000 Ariary


La licence devient active uniquement après validation complète du paiement.


2. TYPE DE LICENCE

Cette licence est une licence EXCLUSIVE.

Après confirmation de l'achat :

- L'instrumentale est retirée du catalogue public.
- Aucun autre artiste ne pourra acheter cette même instrumentale.
- Le Licencié devient le seul utilisateur autorisé de cette version.


3. FORMAT LIVRÉ

Le Licencié reçoit :

- Fichier MP3 haute qualité.
- Fichier WAV haute qualité studio.


4. DROITS D'EXPLOITATION

Le Licencié obtient le droit :

- D'enregistrer une chanson avec cette instrumentale.
- De distribuer son morceau sur les plateformes digitales.
- D'utiliser son morceau dans des projets commerciaux.
- De promouvoir son œuvre sur internet et les réseaux sociaux.


5. EXCLUSIVITÉ

Le Producteur garantit que l'instrumentale ne sera plus proposée à la vente après cette acquisition.

La licence reste attachée au projet musical du Licencié.


6. PROPRIÉTÉ DE LA COMPOSITION

L'achat de cette licence ne signifie pas une cession complète des droits d'auteur de la composition.

Les droits de production musicale restent attribués à JOJOH BEATS.


7. CRÉDIT PRODUCTEUR

Le crédit obligatoire doit apparaître sous la forme :

"Prod. by JOJOH BEATS"



`,


    'Exclusive Pro': `
CONTRAT DE LICENCE EXCLUSIVE PRO – PERSONNALISATION


DE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)

À : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)


DATE D’ENTENTE : [DATE_JOUR]


Le présent contrat concerne l'acquisition d'une licence Exclusive Pro pour l'instrumentale intitulée "[NOM_BEAT]" créée par JOJOH BEATS.


1. FRAIS DE LICENCE

Le prix de cette licence est fixé à :

50 000 Ariary


La licence devient valide après réception du paiement complet.


2. TYPE DE LICENCE

Cette offre correspond à une licence EXCLUSIVE PROFESSIONNELLE.

Elle comprend :

- L'exclusivité totale de l'instrumentale.
- Le retrait définitif du catalogue après achat.
- Un accompagnement personnalisé avant livraison finale.


3. FORMAT LIVRÉ

Le Licencié reçoit :

- Format WAV haute qualité.
- Format MP3 haute qualité.


4. SERVICE DE PERSONNALISATION AVANT LIVRAISON

La particularité de cette licence est la possibilité pour le client de demander des modifications sur la production existante avant réception finale.


Le client peut demander notamment :

- Modification de l'arrangement musical.
- Adaptation de l'introduction ou de la structure.
- Changement d'ambiance générale.
- Ajustement de certains éléments sonores.
- Suppression ou ajout d'éléments musicaux.
- Adaptation de l'instrumentale pour correspondre au style vocal de l'artiste.


Le Producteur effectue les modifications nécessaires afin de proposer une version adaptée au projet artistique du Licencié.


5. VALIDATION DE LA VERSION FINALE

Une fois les modifications terminées et la version finale validée par le Licencié, les fichiers définitifs sont envoyés.


6. DROITS D'EXPLOITATION

Le Licencié peut :

- Exploiter commercialement son morceau.
- Distribuer son projet sur les plateformes numériques.
- Utiliser son œuvre dans des contenus audiovisuels.


7. CRÉDIT PRODUCTEUR

Le crédit doit apparaître sous la forme :

"Prod. by JOJOH BEATS"



`,
    'Custom Instrument': `
CONTRAT DE COMMANDE D'INSTRUMENTALE PERSONNALISÉE


DE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)

À : [NOM_CLIENT] (« Client »)


DATE D’ENTENTE : [DATE_JOUR]


Le présent contrat concerne la création d'une instrumentale originale réalisée spécialement pour le projet artistique du Client par JOJOH BEATS.


1. TARIF DE CRÉATION

Le prix de la commande personnalisée est fixé à :

60 000 Ariary


La production commence après validation du paiement ou de l'accord établi entre le Producteur et le Client.


2. CONCEPT DE LA CRÉATION

Contrairement aux licences classiques, cette offre correspond à une création sur mesure.

Le Producteur réalise une nouvelle instrumentale adaptée aux besoins spécifiques du Client.


3. INFORMATIONS FOURNIES PAR LE CLIENT

Le Client peut transmettre :

- Le style musical souhaité.
- L'ambiance recherchée.
- Les artistes ou morceaux de référence.
- Le tempo souhaité (BPM).
- La direction artistique du projet.
- Les émotions ou thèmes recherchés.


4. PROCESSUS DE PRODUCTION

Le Producteur compose une instrumentale originale en prenant en compte les indications fournies par le Client.

Des ajustements peuvent être effectués afin d'obtenir une version correspondant au mieux à la vision artistique du projet.


5. FORMAT DE LIVRAISON

La version finale peut être livrée selon l'accord établi :

- WAV haute qualité.
- MP3 haute qualité.


6. DROITS ET UTILISATION

Les conditions d'exploitation, d'utilisation et d'éventuelle exclusivité sont définies selon l'accord conclu entre le Producteur et le Client.


7. CRÉDIT PRODUCTEUR

Sauf accord contraire, le crédit de production recommandé est :

"Prod. by JOJOH BEATS"



`
};