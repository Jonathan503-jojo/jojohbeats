// ============================================================
// CONFIG.JS — Constantes, variables partagées, DOM, utilitaires
// ============================================================

const SHEET_BEST_API_URL = "https://api.sheetbest.com/sheets/5439dfdb-e590-4f3b-a96e-f608298a73da";
const SITE_BASE_URL = "https://jojoh.kesug.com";
const colorThief = new ColorThief();

// --- RÉFÉRENCES DOM GLOBALES ---
const beatsContainer = document.getElementById('beats-container');
const beatsTableBody = document.getElementById('beats-table-body');
const loadingStatus = document.getElementById('loading-status');
const searchInput = document.getElementById('search-input');
const genreSelect = document.getElementById('genre-select');
const bpmSelect = document.getElementById('bpm-select');
const sortSelect = document.getElementById('sort-select');
const globalPlayer = document.getElementById('global-player');
const audioElement = document.getElementById('audio-element');
const playerPlayBtn = document.getElementById('player-play-btn');
const playerPrevBtn = document.getElementById('player-prev-btn');
const playerNextBtn = document.getElementById('player-next-btn');
const playerTitle = document.getElementById('player-title');
const playerGenre = document.getElementById('player-genre');
const playerImage = document.getElementById('player-image');
const playerCloseBtn = document.getElementById('player-close-btn');
const playerShareBtn = document.getElementById('player-share-btn');
const progressBar = document.getElementById('progress-bar');
const progressContainer = document.getElementById('progress-container');
const currentTimeEl = document.getElementById('current-time');
const totalDurationEl = document.getElementById('total-duration');
const volumeSlider = document.getElementById('volume-slider');
const volumeToggleBtn = document.getElementById('volume-toggle-btn');
const volumeSliderContainer = document.getElementById('volume-slider-container');
const playerShuffleBtn = document.getElementById('player-shuffle-btn');
const playerLoopBtn = document.getElementById('player-loop-btn');

// --- ÉTAT PARTAGÉ ---
let currentBeatsData = [];
let displayedBeats = [];
let playingBeatId = null;
let isShuffle = false;
let isLoop = false;

// --- DONNÉES DES LICENCES ---
const LICENSE_FEATURES = {
    'Basic': [
        "Fichiers MP3 + WAV Haute Qualité",
        "Usage commercial limité (Streaming, Réseaux)",
        "Crédit Obligatoire : (Prod. by JOJOH)",
        "L'instrumentale reste disponible à la vente"
    ],
    'Premium Exclusive': [
        "Fichiers MP3 + WAV Haute Qualité Studio",
        "Retrait Immédiat et Définitif du catalogue",
        "Usage commercial complet et illimité",
        "Vous devenez le seul utilisateur de cette version"
    ],
    'Exclusive Pro': [
        "Fichiers WAV + MP3 Qualité Master",
        "Personnalisation sur mesure de la structure",
        "Modifications de l'arrangement et de l'ambiance",
        "Adaptation complète selon votre projet vocal"
    ],
    'Custom Instrument': [
        "Composition originale de A à Z (Sur Mesure)",
        "Vous choisissez le style, l'ambiance et le BPM",
        "Ajustements collaboratifs pas à pas",
        "Livraison WAV + MP3 de haute qualité"
    ]
};

// --- MODÈLES DE CONTRATS ---
const CONTRACT_TEMPLATES = {
    'Basic': `CONTRAT DE LICENCE NON-EXCLUSIVE – BASIC\n\nDE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)\nÀ : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)\n\nDATE D'ENTENTE : [DATE_JOUR]\n\nLe présent contrat concerne la licence de l'instrumentale intitulée "[NOM_BEAT]" créée et produite par Jonathan, connu professionnellement sous le nom de JOJOH BEATS.\n\n1. FRAIS DE LICENCE\nLe montant de cette licence est fixé à : 20 000 Ariary\nLa licence devient valide uniquement après réception complète du paiement.\n\n2. TYPE DE LICENCE\nCette licence est une licence NON EXCLUSIVE.\nLe Producteur conserve tous ses droits sur l'instrumentale et peut continuer à proposer cette même œuvre à d'autres artistes.\n\n3. FORMAT LIVRÉ\nLe Licencié reçoit l'instrumentale dans les formats disponibles :\n- MP3 haute qualité\n- WAV haute qualité\n\n4. DROITS D'UTILISATION\nLe Licencié est autorisé à :\n- Utiliser l'instrumentale pour créer une chanson originale.\n- Publier son morceau sur les plateformes digitales.\n- Utiliser son morceau sur les réseaux sociaux.\n- Exploiter son projet selon les limites définies par cette licence.\n\n5. RESTRICTIONS\nLe Licencié ne peut pas :\n- Revendre l'instrumentale originale.\n- Donner l'accès au fichier instrumental à une autre personne.\n- Déclarer être le compositeur exclusif de la musique.\n\n6. CRÉDIT PRODUCTEUR\nLe crédit obligatoire doit apparaître sous la forme :\n"Prod. by JOJOH BEATS" ou "Produit par JOJOH"\n\n7. PROPRIÉTÉ\nLa composition instrumentale originale reste la PROPERTY de JOJOH BEATS.\nCette licence accorde uniquement un droit d'utilisation.`,

    'Premium Exclusive': `CONTRAT DE LICENCE EXCLUSIVE – PREMIUM EXCLUSIVE\n\nDE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)\nÀ : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)\n\nDATE D'ENTENTE : [DATE_JOUR]\n\nLe présent contrat concerne l'acquisition d'une licence exclusive pour l'instrumentale intitulée "[NOM_BEAT]" créée par JOJOH BEATS.\n\n1. FRAIS DE LICENCE\nLe prix de cette licence exclusive est fixé à : 40 000 Ariary\nLa licence devient active uniquement après validation complète du paiement.\n\n2. TYPE DE LICENCE\nCette licence est une licence EXCLUSIVE.\nAprès confirmation de l'achat :\n- L'instrumentale est retirée du catalogue public.\n- Aucun autre artiste ne pourra acheter cette même instrumentale.\n- Le Licencié devient le seul utilisateur autorisé de cette version.\n\n3. FORMAT LIVRÉ\nLe Licencié reçoit :\n- Fichier MP3 haute qualité.\n- Fichier WAV haute qualité studio.\n\n4. DROITS D'EXPLOITATION\nLe Licencié obtient le droit :\n- D'enregistrer une chanson avec cette instrumentale.\n- De distribuer son morceau sur les plateformes digitales.\n- D'utiliser son morceau dans des projets commerciaux.\n- De promouvoir son œuvre sur internet et les réseaux sociaux.\n\n5. EXCLUSIVITÉ\nLe Producteur garantit que l'instrumentale ne sera plus proposée à la vente après cette acquisition.\nLa licence reste attachée au projet musical du Licencié.\n\n6. PROPRIÉTÉ DE LA COMPOSITION\nL'achat de cette licence ne signifie pas une cession complète des droits d'auteur de la composition.\nLes droits de production musicale restent attribués à JOJOH BEATS.\n\n7. CRÉDIT PRODUCTEUR\nLe crédit obligatoire doit apparaître sous la forme :\n"Prod. by JOJOH BEATS"`,

    'Exclusive Pro': `CONTRAT DE LICENCE EXCLUSIVE PRO – PERSONNALISATION\n\nDE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)\nÀ : [NOM_CLIENT] (« Artiste », ci-après dénommé le « Licencié »)\n\nDATE D'ENTENTE : [DATE_JOUR]\n\nLe présent contrat concerne l'acquisition d'une licence Exclusive Pro pour l'instrumentale intitulée "[NOM_BEAT]" créée par JOJOH BEATS.\n\n1. FRAIS DE LICENCE\nLe prix de cette licence est fixé à : 50 000 Ariary\nLa licence devient valide après réception du paiement complet.\n\n2. TYPE DE LICENCE\nCette offre correspond à une licence EXCLUSIVE PROFESSIONNELLE.\nElle comprend :\n- L'exclusivité totale de l'instrumentale.\n- Le retrait définitif du catalogue après achat.\n- Un accompagnement personnalisé avant livraison finale.\n\n3. FORMAT LIVRÉ\nLe Licencié reçoit :\n- Format WAV haute qualité.\n- Format MP3 haute qualité.\n\n4. SERVICE DE PERSONNALISATION AVANT LIVRAISON\nLa particularité de cette licence est la possibilité pour le client de demander des modifications sur la production existante avant réception finale.\nLe client peut demander notamment :\n- Modification de l'arrangement musical.\n- Adaptation de l'introduction ou de la structure.\n- Changement d'ambiance générale.\n- Ajustement de certains elements sonores.\n- Suppression ou ajout d'éléments musicaux.\n- Adaptation de l'instrumentale pour correspondre au style vocal de l'artiste.\nLe Producteur effectue les modifications nécessaires afin de proposer une version adaptée au projet artistique du Licencié.\n\n5. VALIDATION DE LA VERSION FINALE\nUne fois les modifications terminées et la version finale validée par le Licencié, les fichiers définitifs sont envoyés.\n\n6. DROITS D'EXPLOITATION\nLe Licencié peut :\n- Exploiter commercialement son morceau.\n- Distribuer son projet sur les plateformes numériques.\n- Utiliser son œuvre dans des contenus audiovisuels.\n\n7. CRÉDIT PRODUCTEUR\nLe crédit doit apparaître sous la forme :\n"Prod. by JOJOH BEATS"`,

    'Custom Instrument': `CONTRAT DE COMMANDE D'INSTRUMENTALE PERSONNALISÉE\n\nDE : Jonathan (« Producteur », ci-après dénommé le « Concédant »)\nÀ : [NOM_CLIENT] (« Client »)\n\nDATE D'ENTENTE : [DATE_JOUR]\n\nLe présent contrat concerne la création d'une instrumentale originale réalisée spécialement pour le projet artistique du Client par JOJOH BEATS.\n\n1. TARIF DE CRÉATION\nLe prix de la commande personnalisée est fixé à : 60 000 Ariary\nLa production commence après validation du paiement ou de l'accord établi entre le Producteur et le Client.\n\n2. CONCEPT DE LA CRÉATION\nContrairement aux licences classiques, cette offre correspond à une création sur mesure.\nLe Producteur réalise une nouvelle instrumentale adaptée aux besoins spécifiques du Client.\n\n3. INFORMATIONS FOURNIES PAR LE CLIENT\nLe Client peut transmettre :\n- Le style musical souhaité.\n- L'ambiance recherchée.\n- Les artistes ou morceaux de référence.\n- Le tempo souhaité (BPM).\n- La direction artistique du projet.\n- Les émotions ou thèmes recherchés.\n\n4. PROCESSUS DE PRODUCTION\nLe Producteur compose une instrumentale originale en prenant en compte les indications fournies par le Client.\nDes ajustements peuvent être effectués afin d'obtenir une version correspondant au mieux à la vision artistique du projet.\n\n5. FORMAT DE LIVRAISON\nLa version finale peut être livrée selon l'accord établi :\n- WAV haute qualité.\n- MP3 haute qualité.\n\n6. DROITS ET UTILISATION\nLes conditions d'exploitation, d'utilisation et d'éventuelle exclusivité sont définies selon l'accord conclu entre le Producteur et le Client.\n\n7. CRÉDIT PRODUCTEUR\nSauf accord contraire, le crédit de production recommandé est : "Prod. by JOJOH BEATS"`
};

// --- FONCTIONS UTILITAIRES PARTAGÉES ---

function formatTime(seconds) {
    if (isNaN(seconds)) return "0:00";
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
}

function getCleanPrice(beat) {
    let rawPrice = beat.prix_Mvola || beat.prix || beat.Prix || "0";
    if (typeof rawPrice === 'number') return rawPrice;
    let cleanString = rawPrice.toString().replace(/[^0-9]/g, '');
    let finalPrice = parseInt(cleanString, 10);
    return isNaN(finalPrice) ? 0 : finalPrice;
}

function formatDirectUrl(url) {
    if (!url) return '';
    let cleanUrl = url.trim();
    const match = cleanUrl.match(/\/d\/([^\/]+)/) || cleanUrl.match(/id=([^&]+)/);
    if (match && match[1]) {
        return `https://docs.google.com/uc?export=open&id=${match[1]}`;
    }
    return cleanUrl;
}

function updateThemeFromImage(imageUrl) {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.src = imageUrl;
    img.onload = () => {
        try {
            const palette = colorThief.getPalette(img, 2);
            if (palette) {
                const color1 = `rgb(${palette[0].join(',')})`;
                const color2 = `rgb(${palette[1].join(',')})`;
                const gradient = `linear-gradient(135deg, ${color1}, ${color2}, #0a0a0c)`;
                document.getElementById('main-body').style.background = gradient;
                const overlay = document.getElementById('player-overlay');
                if (overlay) overlay.style.background = gradient.replace('0.9)', '0.95)');
            }
        } catch(e) { console.error("Erreur palette", e); }
    };
}
