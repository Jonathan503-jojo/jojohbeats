const SHEET_BEST_API_URL = "https://api.sheetbest.com/sheets/5439dfdb-e590-4f3b-a96e-f608298a73da";

const addForm = document.getElementById('add-beat-form');
const adminStatus = document.getElementById('admin-status');
const adminBeatsList = document.getElementById('admin-beats-list');
const editIndexField = document.getElementById('edit-index');
const submitBtn = document.getElementById('submit-btn');
const cancelBtn = document.getElementById('cancel-btn');
const searchInput = document.getElementById('admin-search');

let catalogue = [];

// 1. Charger le catalogue
async function loadAdminCatalogue() {
    try {
        const response = await fetch(SHEET_BEST_API_URL);
        catalogue = await response.json();
        renderAdminList(catalogue);
        updateDashboard(catalogue);
    } catch (e) {
        adminStatus.innerHTML = "Erreur de chargement des données.";
    }
}

// Stats Dashboard
function updateDashboard(beats) {
    const total = beats.length;
    const dispo = beats.filter(b => b.statut === "available" || !b.statut).length;
    document.getElementById('stat-total').textContent = total;
    document.getElementById('stat-dispo').textContent = dispo;
    document.getElementById('stat-vendu').textContent = total - dispo;
}

// 2. Recherche et Rendu
searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase();
    const filtered = catalogue.filter(b => 
        (b.titre && b.titre.toLowerCase().includes(query)) || 
        (b.id && b.id.toLowerCase().includes(query))
    );
    renderAdminList(filtered);
});

function renderAdminList(beats) {
    adminStatus.classList.add('hidden');
    adminBeatsList.classList.remove('hidden');
    adminBeatsList.innerHTML = '';
    
    beats.forEach((beat, index) => {
        // Trouver l'index original dans le catalogue complet (si filtré)
        const originalIndex = catalogue.indexOf(beat);
        const isAvailable = (beat.statut === "available" || !beat.statut);
        
        const row = document.createElement('div');
        row.className = `p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 border ${isAvailable ? 'border-neutral-800 bg-neutral-950' : 'border-rose-900/30 bg-rose-950/10'}`;
        
        row.innerHTML = `
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 ${isAvailable ? 'bg-neutral-800' : 'bg-rose-950'} rounded flex items-center justify-center text-xs font-bold">${beat.id}</div>
                <div>
                    <h3 class="font-bold text-sm">${beat.titre}</h3>
                    <p class="text-xs font-bold ${isAvailable ? 'text-emerald-500' : 'text-rose-500'} uppercase">${beat.statut || 'Disponible'}</p>
                    ${!isAvailable ? `<p class="text-[10px] text-neutral-400 mt-1">Vendu à: ${beat.acheteur || 'Inconnu'} | ${beat.license || ''} | ${beat.date_vente || ''}</p>` : ''}
                </div>
            </div>
            <div class="flex gap-2">
                <button onclick="editBeat(${originalIndex})" class="px-3 py-1 bg-blue-900/20 text-blue-400 hover:bg-blue-900/40 rounded text-xs">Edit</button>
                <button onclick="deleteBeat(${originalIndex})" class="px-3 py-1 bg-red-900/20 text-red-500 hover:bg-red-900/40 rounded text-xs"><i class="fas fa-trash"></i></button>
            </div>
        `;
        adminBeatsList.appendChild(row);
    });
}

// 3. Éditer
window.editBeat = function(index) {
    const beat = catalogue[index];
    document.getElementById('edit-index').value = index;
    document.getElementById('beat-id').value = beat.id;
    document.getElementById('beat-title').value = beat.titre;
    document.getElementById('beat-price').value = beat.prix_Mvola;
    document.getElementById('beat-category').value = beat.categorie;
    document.getElementById('beat-audio').value = beat.audio_url;
    document.getElementById('beat-duree').value = beat.duree;
    document.getElementById('beat-bpm').value = beat.bpm;
    document.getElementById('beat-image').value = beat.image_url;
    
    // Champs Vente
    document.getElementById('beat-status').value = beat.statut || 'available';
    document.getElementById('beat-buyer').value = beat.acheteur || '';
    document.getElementById('beat-license-type').value = beat.license || 'none';
    document.getElementById('beat-sale-date').value = beat.date_vente || '';
    
    document.getElementById('form-title').textContent = "Modifier le Beat";
    submitBtn.textContent = "Mettre à jour";
    cancelBtn.classList.remove('hidden');
    window.scrollTo({top: 0, behavior: 'smooth'});
};

cancelBtn.onclick = () => {
    addForm.reset();
    editIndexField.value = "";
    document.getElementById('form-title').textContent = "Ajouter un Beat";
    submitBtn.textContent = "Enregistrer";
    cancelBtn.classList.add('hidden');
};

// 4. Submit
addForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const index = editIndexField.value;
    const data = {
        id: document.getElementById('beat-id').value,
        titre: document.getElementById('beat-title').value,
        prix_Mvola: parseInt(document.getElementById('beat-price').value),
        categorie: document.getElementById('beat-category').value,
        audio_url: document.getElementById('beat-audio').value,
        duree: document.getElementById('beat-duree').value,
        bpm: parseInt(document.getElementById('beat-bpm').value),
        image_url: document.getElementById('beat-image').value,
        statut: document.getElementById('beat-status').value,
        acheteur: document.getElementById('beat-buyer').value,
        license: document.getElementById('beat-license-type').value,
        date_vente: document.getElementById('beat-sale-date').value
    };

    if (index === "") {
        await fetch(SHEET_BEST_API_URL, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([data]) });
    } else {
        await fetch(`${SHEET_BEST_API_URL}/${index}`, { method: 'PATCH', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data) });
    }
    addForm.reset();
    cancelBtn.click();
    loadAdminCatalogue();
});

// 5. Supprimer
window.deleteBeat = async function(index) {
    if(!confirm("Supprimer ce beat définitivement ?")) return;
    await fetch(`${SHEET_BEST_API_URL}/${index}`, { method: 'DELETE' });
    loadAdminCatalogue();
};

loadAdminCatalogue();